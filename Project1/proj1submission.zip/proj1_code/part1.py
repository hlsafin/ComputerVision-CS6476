import torch
import math
import torch.nn as nn
import torch.nn.functional as F
import math
import torch
import math
import torch.nn as nn
import torch.nn.functional as F
import math
import os
from typing import List, Tuple
import torch
import math
import torch.nn as nn
import torch.nn.functional as F
import math
import numpy as np
import PIL
import torch
import torch.utils.data as data
import torchvision

def my_1dfilter(signal: torch.FloatTensor,
                kernel: torch.FloatTensor) -> torch.FloatTensor:
    """Filters the signal by the kernel.

    output = signal * kernel where * denotes the cross-correlation function.
    Cross correlation is similar to the convolution operation with difference
    being that in cross-correlation we do not flip the sign of the kernel.

    Reference: 
    - https://mathworld.wolfram.com/Cross-Correlation.html
    - https://mathworld.wolfram.com/Convolution.html

    Note:
    1. The shape of the output should be the same as signal.
    2. You may use zero padding as required. Please do not use any other 
       padding scheme for this function.
    3. Take special care that your function performs the cross-correlation 
       operation as defined even on inputs which are asymmetric.

    Args:
        signal (torch.FloatTensor): input signal. Shape=(N,)
        kernel (torch.FloatTensor): kernel to filter with. Shape=(K,)

    Returns:
        torch.FloatTensor: filtered signal. Shape=(N,)
    """
    filtered_signal = torch.FloatTensor()
    #result = F.pad(input=lowpass_1dfilter, pad=(0,low_freq_sinusoid.shape[0]-lowpass_1dfilter.shape[0]), mode='constant', value=0)
    #filtered_signal= result*signal
    x= kernel
    lengsize=signal.shape[0]
    z=signal
    #print(x)
    #y=F.pad(x,[1,2])

    #print(F.pad(x[2:],[0,5]))
    #print(F.pad(x[1:],[0,4]))

    #print(F.pad(x,[0,3]))
    #print(F.pad(x,[1,2]))
    #print(F.pad(x,[2,1]))
    #print(F.pad(x,[3,0]))

    #print(F.pad(x[:2],[4,0]))
    #print(F.pad(x[:1],[5,0]))
    list=[]
    if kernel.shape[0]%2==0:
        for y in range(x.shape[0]-1):
            #print(F.pad(x[(x.shape[0]-1-y):],[0,lengsize-y-1]))
            #print(z)
            #print(torch.dot(z,F.pad(x[(x.shape[0]-1-y):],[0,lengsize-y-1])))
            list.append(torch.dot(z,F.pad(x[(x.shape[0]-1-y):],[0,lengsize-y-1])))

        for y in range(lengsize-(x.shape[0]-1)):
            #print(F.pad(x,[y,(lengsize-(x.shape[0]))-y]))
            #print(z)
            #print(torch.dot(z,F.pad(x,[y,(lengsize-(x.shape[0]))-y])))
            list.append(torch.dot(z,F.pad(x,[y,(lengsize-(x.shape[0]))-y])))

        for y in range(x.shape[0]-1):
            #print(F.pad(x[:(x.shape[0]-y-1)],[lengsize+y-x.shape[0]+1,0]))
            print(z)
            #print(torch.dot(z,F.pad(x[:(x.shape[0]-y-1)],[lengsize+y-x.shape[0]+1,0])))
            #list.append(torch.dot(z,F.pad(x[:(x.shape[0]-y-1)],[lengsize+y-x.shape[0]+1,0])))
        filtered_signal= torch.FloatTensor(list)
        
        return filtered_signal
    else: 
        #print('nope')
        ceil=math.ceil(kernel.shape[0]/2)
        for y in range(x.shape[0]-ceil):
            print(F.pad(x[(x.shape[0]-2-y):],[0,lengsize-y-2]))
            #print(z)
            #print(torch.dot(F.pad(x[(x.shape[0]-1-y):],[0,lengsize-y-1]),z))
            list.append(torch.dot(z,F.pad(x[(x.shape[0]-2-y):],[0,lengsize-y-2])))

        for y in range(lengsize-(x.shape[0]-1)):
            print(F.pad(x,[y,(lengsize-(x.shape[0]))-y]))
            #print(z)
            #print(torch.dot(z,F.pad(x,[y,(lengsize-(x.shape[0]))-y])))
            list.append(torch.dot(z,F.pad(x,[y,(lengsize-(x.shape[0]))-y])))
        for y in range(x.shape[0]-ceil):
            
            print(F.pad(x[:(x.shape[0]-y-1)],[lengsize+y-x.shape[0]+1,0]))
        #print(z)
            #print(torch.dot(z,F.pad(x[:(x.shape[0]-y-1)],[lengsize+y-x.shape[0]+1,0])))
            list.append(torch.dot(z,F.pad(x[:(x.shape[0]-y-1)],[lengsize+y-x.shape[0]+1,0])))


        filtered_signal= torch.FloatTensor(list)
        #print(filtered_signal)
        
        return filtered_signal
    #print(filtered_signal)
    #############################################################################
    # TODO: YOUR CODE HERE
    ############################################################################
    
    #raise NotImplementedError
    #############################################################################
    #                             END OF YOUR CODE
    ############################################################################
import glob
import os
from typing import Tuple

import numpy as np
from PIL import Image
from sklearn.preprocessing import StandardScaler


def compute_mean_and_std(dir_name: str) -> Tuple[np.ndarray, np.array]:
  '''
  Compute the mean and the standard deviation of the dataset.

  Note: convert the image in grayscale and then scale to [0,1] before computing
  mean and standard deviation

  Hints: use StandardScalar (check import statement)

  Args:
  -   dir_name: the path of the root dir
  Returns:
  -   mean: mean value of the dataset (np.array containing a scalar value)
  -   std: standard deviation of th dataset (np.array containing a scalar value)
  '''

  mean = None
  std = None


  ############################################################################
  # Student code begin
  ############################################################################
  scaler = StandardScaler()
  for x in os.walk(dir_name):
    a, b, c = x
    for i in c:
      if '.jpg' in i:
        # print(a,i)
        # print(Image(a+'/'+i))
        pix = Image.open(a + '/' + i)
        pic = np.array(pix)
        i = pic / 255
        i = np.reshape(i, (-1, 1))

        scaler.partial_fit(i)

  #             list.append(pic.tolist())

  #             #print(pic.shape)
  # #print(pic.shape)

  # scaler = StandardScaler()
  # # #list=np.asarray(list)
  # print(scaler.fit(list))

  # scaler.partial_fit(i)
  # dataset.append(np.array(i))
  mean = scaler.mean_
  std = np.sqrt(scaler.var_)

  ############################################################################
  # Student code end
  ############################################################################
  return mean, std



import os
import torch
import matplotlib.pyplot as plt

from proj2_code.runner import Trainer
from proj2_code.optimizer import get_optimizer
from proj2_code.simple_net import SimpleNet
from proj2_code.simple_net_dropout import SimpleNetDropout
from proj2_code.my_alexnet import MyAlexNet
from proj2_code.image_loader import ImageLoader
from proj2_code.data_transforms import get_fundamental_transforms, get_data_augmentation_transforms
from proj2_code.stats_helper import compute_mean_and_std
from proj2_code.vis import visualize

from proj2_code.proj2_unit_tests.test_base import verify
from proj2_code.proj2_unit_tests.test_stats_helper import test_mean_and_variance
from proj2_code.proj2_unit_tests.test_image_loader import test_dataset_length, test_unique_vals, test_class_values, test_load_img_from_path
from proj2_code.proj2_unit_tests.test_data_transforms import test_fundamental_transforms
from proj2_code.proj2_unit_tests.test_dl_utils import test_predict_labels, test_compute_loss
from proj2_code.proj2_unit_tests.test_simple_net import test_simple_net
from proj2_code.proj2_unit_tests.test_simple_net_dropout import test_simple_net_dropout
from proj2_code.proj2_unit_tests.test_my_alexnet import test_my_alexnet
from proj2_code.proj2_unit_tests.test_checkpoints import test_simple_net_checkpoint

# flag to modify paths to run better on Colab; change it to true if you want to run on colab

use_colab_paths = False
is_cuda = True
is_cuda = is_cuda and torch.cuda.is_available() # will turn off cuda if the machine doesnt have a GPU

data_base_path = '../data/' if not use_colab_paths else 'data/'
model_base_path = '../model_checkpoints/' if not use_colab_paths else 'model_checkpoints/'
dataset_mean, dataset_std = compute_mean_and_std(data_base_path)
inp_size = (224, 224)
optimizer_config = {
  "optimizer_type": "sgd",
  "lr": 4.5e-3,
  "weight_decay": 1e-2
}
my_alexnet = MyAlexNet()
optimizer = get_optimizer(my_alexnet, optimizer_config)

trainer = Trainer(data_dir=data_base_path,
                  model = my_alexnet,
                  optimizer = optimizer,
                  model_dir = os.path.join(model_base_path, 'alexnet'),
                  train_data_transforms = get_data_augmentation_transforms(inp_size, dataset_mean, dataset_std),
                  test_data_transforms = get_fundamental_transforms(inp_size, dataset_mean, dataset_std),
                  batch_size = 32,
                  load_from_disk = False,
                  cuda = is_cuda
                 )

trainer.train(num_epochs=5)

import cv2
import numpy as np
import matplotlib.pyplot as plt
from proj4_code.utils import *
import scipy

import projection_matrix
# np.set_printoptions(suppress=True) # Suppresses printing in scientific notation

from unit_tests.part1_unit_test import (
    verify,
    test_projection,
    test_objective_func,
    test_decompose_camera_matrix,
    test_calculate_camera_center,
    test_estimate_camera_matrix)

initial_guess_K = np.array([[ 500,   0, 535],
                            [   0, 500, 390],
                            [   0,   0,  -1]])

initial_guess_wRc_T = np.array([[ 0.5,   -1,  0],
                            [   0,    0, -1],
                            [   1,  0.5,  0]])

initial_guess_I_wtc = np.array([[   1,    0, 0, 300],
                              [   0,    1, 0, 300],
                              [   0,    0, 1,  30]])

initial_guess_P = np.matmul(initial_guess_K, np.matmul(initial_guess_wRc_T, initial_guess_I_wtc))

# set the paths and load the data
pts2d_path = '../data/pts2d-pic_b.txt'
pts3d_path = '../data/pts3d.txt'
img_path   = '../data/pic_b.jpg'

points_2d = np.loadtxt(pts2d_path)
points_3d = np.loadtxt(pts3d_path)
img = load_image(img_path)

P = projection_matrix.estimate_camera_matrix(points_2d, points_3d, initial_guess_P)

print('The projection matrix is\n', P)

[projected_2d_pts, residual] = evaluate_points(P, points_2d, points_3d);

# residual is the sum of Euclidean distances between actual and projected points
print('The total residual is {:f}'.format(residual))
visualize_points_image(points_2d, projected_2d_pts, '../data/pic_b.jpg')


K, cRw = projection_matrix.decompose_camera_matrix(P)

center = projection_matrix.calculate_camera_center(P, K, cRw)

points_3d = np.array([[0    , 0,  0],
                      [23.5 , 0,  0],
                      [0    , 21, 0],
                      [0    , 0,  4],
                      [23.5 , 0 , 4],
                      [23.5 , 21, 4],
                      [0    , 21, 4]])

image1_path = '../data/book_img1.jpg'
image2_path = '../data/book_img2.jpg'

img1 = load_image(image1_path)
img2 = load_image(image2_path)

points2d_img1 = np.array([[700,  3210],
                          [230,  1710],
                          [2565, 2410],
                          [636,  2878],
                          [176,  1465],
                          [1555, 1085],
                          [2640, 2135]])

points2d_img2 = np.array([[2356, 3210],
                          [154, 2169],
                          [2794, 1884],
                          [2487, 2902],
                          [90, 1873],
                          [1140, 1073 ],
                          [2859, 1577]])


initial_guess_K = np.array([[ 500,   0, 2024],
                            [   0, 500, 1518],
                            [   0,   0,  1]])

initial_guess_wRc_T = np.array([[ 0.5,   -1,  0],
                            [   0,    0, -1],
                            [   1,  0.5,  0]])

initial_guess_I_t = np.array([[   1,    0, 0, -30],
                              [   0,    1, 0, -30],
                              [   0,    0, 1, 30]])

initial_guess_P = np.matmul(initial_guess_K, np.matmul(initial_guess_wRc_T, initial_guess_I_t))

# set the paths and load the data
pts2d_path = '../data/pts2d_image1.npy'
pts3d_path = '../data/pts3d_fiducial.npy'

points_2d = np.loadtxt(pts2d_path)
points_3d = np.loadtxt(pts3d_path)
img = load_image(image1_path)
np.array(img.shape[:2])/2


P1 = projection_matrix.estimate_camera_matrix(points_2d, points_3d, initial_guess_P)
print('The projection matrix is\n', P1)

[projected_2d_pts, residual] = evaluate_points(P1, points_2d, points_3d);
print('The total residual is {:f}'.format(residual))
visualize_points_image(points_2d, projected_2d_pts, image1_path)


# set the pats and load the data
pts2d_path = '../data/pts2d_image2.npy'
pts3d_path = '../data/pts3d_fiducial.npy'

points_2d = np.loadtxt(pts2d_path)
points_3d = np.loadtxt(pts3d_path)
img = load_image(image1_path)
np.array(img.shape[:2])/2

initial_guess_K = np.array([[ 500,   0, 2024],
                            [   0, 500, 1518],
                            [   0,   0,  1]])

initial_guess_wRc_T = np.array([[ 0.5,   -1,  0],
                            [   0,    0, -1],
                            [   1,  0.5,  -0.5]])

initial_guess_I_t = np.array([[   1,    0, 0, -30],
                              [   0,    1, 0, -10],
                              [   0,    0, 1, 30]])

initial_guess_P = np.matmul(initial_guess_K, np.matmul(initial_guess_wRc_T, initial_guess_I_t))

P2 = projection_matrix.estimate_camera_matrix(points_2d, points_3d, initial_guess_P)
#M = sc.calculate_projection_matrix(points_2d, points_3d)
print('The projection matrix is\n', P2)

[projected_2d_pts, residual] = evaluate_points(P2, points_2d, points_3d);
print('The total residual is {:f}'.format(residual))
visualize_points_image(points_2d, projected_2d_pts, image2_path)
#visualize_points(points_2d, projected_2d_pts)


K1, R1 = projection_matrix.decompose_camera_matrix(P1)
center_1 = projection_matrix.calculate_camera_center(P1, K1, R1);
print(center_1)

K2, R2 = projection_matrix.decompose_camera_matrix(P2)
center_2 = projection_matrix.calculate_camera_center(P2, K2, R2);
print(center_2)

plot3dview_2_cameras(points_3d, center_1, center_2, R1.T, R2.T)


# find the 3D coordinates of your box-like fiducial object.
# The following are coordinates for the image we provide you,
# please replace them with your own.
# Keep in mind that you'll need 8 coordinates of all 8 vertices
# of your box-like fiducial object.
points_3d = np.array([[0    , 0,  0],
                      [23.5 , 0,  0],
                      [23.5 , 21, 0],
                      [0    , 21, 0],
                      [0    , 0,  4],
                      [23.5 , 0 , 4],
                      [23.5 , 21, 4],
                      [0    , 21, 4]])

# visualize your bounding box.
projection_matrix.visualize_bounding_box(P1, points_3d, img1)
projection_matrix.visualize_bounding_box(P2, points_3d, img2)

from unit_tests.part3_unit_test import (
    verify,
    test_transformation_matrix,
    test_convert_3d_points_to_camera_coordinate,
    test_projection_from_camera_coordinates)

print('Test for transformation matrix:', verify(test_transformation_matrix))

print('Test for transformation to camera coordinates:', verify(test_convert_3d_points_to_camera_coordinate))


print('Test for projection from camera coordinates:', verify(test_projection_from_camera_coordinates))

from camera_coordinates import (
    transformation_matrix,
    convert_3d_points_to_camera_coordinate,
    projection_from_camera_coordinates,
    visualize_bounding_box_camera_coordinates)


image1_path = '../data/book_img1.jpg'
image2_path = '../data/book_img2.jpg'

img1 = load_image(image1_path)
img2 = load_image(image2_path)


# the 3D coordinates of your box-like fiducial object.
points_3d = np.array([[0    , 0,  0],
                      [23.5 , 0,  0],
                      [23.5 , 21, 0],
                      [0    , 21, 0],
                      [0    , 0,  4],
                      [23.5 , 0 , 4],
                      [23.5 , 21, 4],
                      [0    , 21, 4]])


## Draw bounding box for image 1

# visualize bounding box, P1 is the projection matrix you estimated for image 1
visualize_bounding_box_camera_coordinates(P1, points_3d, img1)


## Draw bounding box for image 2

# visualize bounding box, P2 is the projection matrix you estimated for image 2
visualize_bounding_box_camera_coordinates(P2, points_3d, img2)


from unit_tests.test_dlt import test_generate_homogenous_system, test_get_eigenvector_with_smallest_eigenvector


print('Test for generate_homogenous_system:', verify(test_generate_homogenous_system))

print('Test for get_eigenvector_with_smallest_eigenvector:', verify(test_get_eigenvector_with_smallest_eigenvector))



# set the paths and load the data
pts2d_path = '../data/pts2d-pic_b.txt'
pts3d_path = '../data/pts3d.txt'
img_path   = '../data/pic_b.jpg'

points_2d = np.loadtxt(pts2d_path)
points_3d = np.loadtxt(pts3d_path)
img = load_image(img_path)


print('Shape of 2D points', points_2d.shape)
print('Shape of 3D points', points_3d.shape)

from dlt import estimate_projection_matrix_dlt

P = estimate_projection_matrix_dlt(points_2d, points_3d)


print('The projection matrix is\n', P)

[projected_2d_pts, residual] = evaluate_points(P, points_2d, points_3d);

# residual is the sum of Euclidean distances between actual and projected points
print('The total residual is {:f}'.format(residual))
visualize_points_image(points_2d, projected_2d_pts, '../data/pic_b.jpg')
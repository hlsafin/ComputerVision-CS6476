import os
import torch
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
import cv2


def imshow1(img):
    fig, axs = plt.subplots()
    axs.imshow(img)
    axs.axis('off')
    plt.show()


def projection_2d_to_3d(P, depth, pose2d):
    """
    This function calculates the inverse projection from 2D feature points to 3D real world coordiantes.

    Args:
    -    P: size is (3,4), camera projection matrix which combines both camera pose and intrinsic matrix
    -    depth: scalar, which provides the depth information (physica distance between you and camera in real world), in meter
    -    pose2d, size (n,2), where n is the number of 2D pose feature points in (x,y) image coordinates

    Returns:SSS
    -    pose3d, size (n,3), where n is the number of 2D pose points. These are the 3D real-world
    coordiantes of human pose in the chair frame

    Hints:
    When only one 2D point is considered, one very easy way to solve this is treating it
    as three equations with three unknowns. However, since this is a linear system,
    it can also be solve via matrix manipulation. You can try to treat the P as a 3*3 matrix plus a 3*1 column vector,
    and see if it helps
    """
    pose3d = None
    ############################################################################
    # TODO: YOUR CODE HERE
    ############################################################################
    # rowsum=P.sum(axis=1)
    # new_mat = P / rowsum[:,np.newaxis]
    p_3by3 = P[:, 0:3]
    p_lastcol = P[:, 3][None, :]
    z = depth
    pose2d = np.hstack((pose2d, np.ones((pose2d.shape[0], 1))))
    # pose3d=np.matmul(np.linalg.inv(p_3by3),   ((pose2d * z) - p_lastcol.T))
    sub = (pose2d * z) - p_lastcol
    pose3d = np.linalg.inv(p_3by3) @ sub.T

    ############################################################################
    #                             END OF YOUR CODE
    ############################################################################
    return pose3d.T


def get_world_vertices(width, height, depth):
    """
    Given the real size of the chair, return the real-world coordinates of the eight vertices
    in the same order as the detected bounding box from part 1
    Args:
        width: width of the chair, from vertex 0 to vertex 1
        height: height of the chair, from vertex 0 to vertex 4
        depth: depth of the chair, from vertex 0 to vertex 2
    Returns:
        vertices_world: (8,3), 8 vertices' real-world coordinates (x,y,z)
    """
    vertices_world = np.zeros((8, 3))

    ############################################################################
    # TODO: YOUR CODE HERE
    ############################################################################
    for x in range(8):
        for y in range(3):
            if x % 2 != 0:
                vertices_world[x][0] = width
            if x >= 4:
                vertices_world[x][1] = height
            if x in (2, 3, 6, 7):
                vertices_world[x][2] = depth

    ############################################################################
    #                             END OF YOUR CODE
    ############################################################################

    return vertices_world


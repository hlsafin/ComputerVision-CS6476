
from PIL import Image
import matplotlib.pyplot as plt
# import mediapipe as mp
import numpy as np
import cv2

from proj5_code.utils import *
from proj5_code.my_objectron import *
from proj5_code.pose_estimate import *
from proj5_code.intersection import *
from proj5_code.pnp import *

from proj5_unit_tests.test_base import *
from proj5_unit_tests.test_my_objectron import *
from proj5_unit_tests.test_pose_estimate import *
from proj5_unit_tests.test_intersection import *
from proj5_unit_tests.test_pnp import *
from proj5_unit_tests.test_utils import *

test_img='../data/10.jpg'
img = cv2.imread(test_img)
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
# plt.imshow(img)
#plt.show()


bounding_boxes_chair_2d, annotated_img = detect_3d_box(test_img)
# plt.imshow(annotated_img)
# plt.show()
# print(bounding_boxes_chair_2d)
print("Testing your objectron detection: ", verify(test_my_objectron))


img_index = cv2.imread('../data/world_frame.png')
img_index = cv2.cvtColor(img_index, cv2.COLOR_BGR2RGB)
# plt.imshow(img_index)
# plt.show()

# You need to measure the size of chair at first, and set their values there.
# For example, the example chair's size is 0.4m * 0.4m *1.0m
size_x = 0.4
size_y = 0.4
size_z = 1.0
vertices_world = get_world_vertices(size_x, size_y, size_z)
print(vertices_world)

initial_box_points_3d = vertices_world
print("Testing your get_world_vertices: ", verify(test_get_world_vertices))

from proj5_code.calibration import calibrate

path2 = '../data/cali2/example2/' # update the path to where you save the pictures
m = 5 # m is the vertice number in x direction
n = 7 # n is the vertice number in y direction

K = calibrate(path2)

# K = np.array([[ 480,   0, 240],
#               [   0, 640, 320],
#               [   0,   0,  1]])

from proj5_code.pnp import perspective_n_points, plot_box_and_camera


bounding_boxes = bounding_boxes_chair_2d
# print(annotated_img.shape)
height = annotated_img.shape[0]
width = annotated_img.shape[1]

box_points_2d = np.array(bounding_boxes)
box_points_2d[:, 0] *= width
box_points_2d[:, 1] *= height

wRc_T, camera_center, P = perspective_n_points(initial_box_points_3d, box_points_2d, K)

# plot_box_and_camera(initial_box_points_3d, camera_center, wRc_T.T)

from proj5_unit_tests.test_pnp import test_perspective_n_points
print("Testing your perspective_n_points: ", verify(test_perspective_n_points))

test_img='../data/10.jpg'

land_mark, annotated_image = hand_pose_img(test_img)
print('Detected landmark numbers: ', len(land_mark))
#imshow1(annotated_image)

left_thumb=land_mark[22]
print(left_thumb)

print("Testing your pose estimation: ", verify(test_pose_estimate))


P = K.dot(wRc_T.dot( np.hstack((np.eye(3),-1.0*camera_center)) ))
print(P)


print(land_mark.shape)

depth = 1.91

pose3d_landmark = projection_2d_to_3d(P, depth, land_mark)

left_hand = pose3d_landmark[22]
print("Your 3D pose landmark of the left hand is ", left_hand)

print("Testing your 3d human pose estimate: ", verify(test_projection_2d_to_3d))


# Test if you can project the 0 vertic back correctly
P.dot(np.array([0,0,0,1]).T)/P.dot(np.array([0,0,0,1]).T)[2]




print('Test for intersection checking:', verify(test_check_hand_inside_bounding_box))

annotated_img = draw_box_intersection(img, left_hand, vertices_world, bounding_boxes_chair_2d)


# plt.imshow(annotated_img)
# plt.show()